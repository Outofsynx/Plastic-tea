<?php

$username=$_POST['username'];
