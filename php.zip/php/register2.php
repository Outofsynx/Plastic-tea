<?php
require_once "connect.php";
$username=$_POST['username'];
$firstname=$_POST['firstname'];
$lastname=$_POST['achternaam'];
$password=$_POST['wachtwoord'];
// encrypting the password
 //    
$hash=password_hash($password,PASSWORD_BCRYPT);
// hashing password
$sql="INSERT INTO `students`(`username`, `firstname`, `lastname`, `password`) 
VALUES ('$username','$firstname','$lastname','$hash')";
//adding the sql 
$conn->query($sql);



?>