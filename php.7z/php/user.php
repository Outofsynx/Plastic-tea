<?php
session_start();
$naam=$_SESSION['naam'];
;?>
<h1>welkom<?php echo($naam)?></h1>